package controller;

import dao.ThesisDao;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@WebServlet(name = "SupervisorSearchThesesServlet")
public class SupervisorSearchThesesServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //Get logged teacher ID
        HttpSession session = request.getSession(false);
        int userID = (int) session.getAttribute("id");
        ThesisDao thesisDao = new ThesisDao();
        //Get thesis records for obtained Faculty Number
        thesisDao.showSupervisorTheses(userID);
        //Printing records as a table
        String supervisorThesesTable = thesisDao.printTeacherThesisTable();
        //Saving table into request to be used on another page
        request.setAttribute("resultTable", supervisorThesesTable);
        //Redirecting to another page with results
        RequestDispatcher dispatcher = request.getRequestDispatcher("resultThesis.jsp");
        dispatcher.forward(request,response);
    }
}
