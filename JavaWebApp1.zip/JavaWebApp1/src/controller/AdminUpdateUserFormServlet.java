package controller;

import bean.UserBean;
import dao.ReadRecordDao;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(name = "AdminUpdateUserFormServlet")
public class AdminUpdateUserFormServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //Get userID
        int userID = Integer.parseInt(request.getParameter("ID"));
        //Use the userID and a ReadRecord obj to get the user data
        ReadRecordDao rrd = new ReadRecordDao();
        UserBean userBean = rrd.doRea(userID);
        request.setAttribute("user", userBean);
        //pass control on the JSP
        String url = "/updateForm.jsp";
        RequestDispatcher dispatcher = request.getRequestDispatcher(url);
        dispatcher.forward(request,response);
    }
}
