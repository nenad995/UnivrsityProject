package controller;

import bean.UserBean;
import dao.EditorDao;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(name = "EditorUpdateUserFormServlet")
public class EditorUpdateUserFormServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //Get userID
        int userID = Integer.parseInt(request.getParameter("ID"));
        //Use the userID and EditorReadRecord obj to get the user data
        EditorDao editorDao = new EditorDao();
        UserBean userBean = editorDao.editorDoRead(userID);
        request.setAttribute("user", userBean);
        //Redirect to editorUpdateUserForm
        String url = "/editorUpdateUserForm.jsp";
        RequestDispatcher dispatcher = request.getRequestDispatcher(url);
        dispatcher.forward(request, response);
    }
}
