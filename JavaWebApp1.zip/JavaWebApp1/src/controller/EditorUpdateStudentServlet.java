package controller;

import bean.StudentBean;
import dao.EditorDao;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(name = "EditorUpdateStudentServlet")
public class EditorUpdateStudentServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //Get the form data
        int userID = Integer.parseInt(request.getParameter("uid"));
        int facNum = Integer.parseInt(request.getParameter("facNum"));
        StudentBean studentBean = new StudentBean();
        studentBean.setId(userID);
        studentBean.setFacultyNumber(facNum);
        EditorDao editorDao = new EditorDao();
        editorDao.editorDoUpdateStudent(studentBean);
        //pass control to showUsersTable
        String url = "/editorShowAllTheses";
        RequestDispatcher dispatcher = request.getRequestDispatcher(url);
        dispatcher.forward(request, response);
    }
}
