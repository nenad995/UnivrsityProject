package controller;

import bean.DBConnection;
import dao.ThesisDao;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

@WebServlet(name = "FileUploadServlet")
@MultipartConfig(maxFileSize = 16177215) //Upload file up to 16MB
public class FileUploadServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        int userID = (int) session.getAttribute("id");
        ThesisDao thesisDao = new ThesisDao();
        int facNum = thesisDao.getFacultyNumber(userID);
        int thesisID = thesisDao.showYourThesisID(facNum);
        request.setAttribute("thesisID", thesisID);
        //Retrives <input type="file" name="thesisFile">
        Part filePart = request.getPart("thesisFile");
        InputStream inputStream = null;
        if (filePart != null) {
            inputStream = filePart.getInputStream();
        }
        String message = null;
        String insertQuery = "INSERT INTO files (thesisID, file) VALUES (?,?)";
        Connection conn = null;
        PreparedStatement ps = null;
        conn = DBConnection.createConnection();
        try {
            ps = conn.prepareStatement(insertQuery);
            ps.setInt(1,thesisID);
            if (inputStream != null){
                ps.setBlob(2, inputStream);
            }
            int row = ps.executeUpdate();
            if (row > 0){
                message = "File successfully uploaded.";
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        request.setAttribute("Message", message);
        getServletContext().getRequestDispatcher("/sHomepage.jsp").forward(request, response);
    }
}
