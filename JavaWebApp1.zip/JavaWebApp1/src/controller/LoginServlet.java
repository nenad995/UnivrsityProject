package controller;

        import bean.UserBean;
        import dao.LoginDao;

        import javax.servlet.ServletException;
        import javax.servlet.annotation.WebServlet;
        import javax.servlet.http.HttpServlet;
        import javax.servlet.http.HttpServletRequest;
        import javax.servlet.http.HttpServletResponse;
        import javax.servlet.http.HttpSession;
        import java.io.IOException;

@WebServlet(name = "LoginServlet")
public class LoginServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String username = request.getParameter("uname");
        String password = request.getParameter("pwd");
        UserBean userBean = new UserBean();
        userBean.setUsername(username);
        userBean.setPassword(password);
        LoginDao loginDao = new LoginDao();
        String userValidation = loginDao.login(userBean);
        if (userValidation.equals("SUCCESS.")){
            if (username.equals("admin")){
                request.getRequestDispatcher("/Console.jsp").forward(request, response);
            } else {
                int userID = loginDao.obtainUserID(userBean);
                HttpSession session = request.getSession();
                session.setAttribute("id", userID);
                if (loginDao.isStudent(userID)) {
                    request.getRequestDispatcher("/sHomepage.jsp").forward(request, response);
                } else if (loginDao.isTeacher(userID)) {
                    request.getRequestDispatcher("/tHomepage.jsp").forward(request, response);
                } else if (username.equals("editor")){
                    request.getRequestDispatcher("/editorHomepage.jsp").forward(request, response);
                } else
                    request.getRequestDispatcher("/StudentOrTeacher.jsp").forward(request, response);
            }
        } else {
            request.setAttribute("errMessage", userValidation);
            request.getRequestDispatcher("/Login.jsp").forward(request, response);
        }
    }
}