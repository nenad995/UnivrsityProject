package controller;

import dao.ThesisDao;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@WebServlet(name = "SearchYourThesisServlet")
public class SearchYourThesisServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //Get logged user ID from session
        HttpSession session = request.getSession(false);
        int userID = (int) session.getAttribute("id");
        ThesisDao thesisDao = new ThesisDao();
        //Get logged user Faculty Number
        int facNum = thesisDao.getFacultyNumber(userID);
        //Get thesis records for obtained Faculty Number
        thesisDao.showYourThesis(facNum);
        //Printing records as a table
        String yourThesisTable = thesisDao.printThesisTable();
        //Saving table into request to be used on another page
        request.setAttribute("yourThesisTable", yourThesisTable);
        //Redirecting to another page with results
        RequestDispatcher dispatcher = request.getRequestDispatcher("resultYourThesisTable.jsp");
        dispatcher.forward(request,response);
    }
}
