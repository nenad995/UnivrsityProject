package controller;

import bean.ThesisBean;
import dao.ThesisDao;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.text.ParseException;

@WebServlet(name = "CreateThesisServlet")
public class CreateThesisServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        ThesisBean thesisBean = new ThesisBean();
        //Getting values from fields and saving them to variables.
        //After that setting values for thesisBean obj.
        int facultyNumber = Integer.parseInt(request.getParameter("facNum"));
        thesisBean.setFacNum(facultyNumber);
        HttpSession session = request.getSession(false);
        int teacherID = (int) session.getAttribute("id");
        thesisBean.setTeacherID(teacherID);
        String date = request.getParameter("defDate");
        thesisBean.setDefenseDate(date);
        String theme = request.getParameter("theme");
        thesisBean.setTheme(theme);
        String shortDescription = request.getParameter("shortDesc");
        thesisBean.setDescription(shortDescription);
        String content = request.getParameter("content");
        thesisBean.setContent(content);
        ThesisDao thesisDao = new ThesisDao();
        String thesisCreated = null;
        try {
            thesisCreated = thesisDao.createThesis(thesisBean);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        if (thesisCreated.equals("SUCCESS.")){
            RequestDispatcher dispatcher = request.getRequestDispatcher("/SupervisorSearchThesesServlet");
            dispatcher.forward(request, response);
        } else {
            request.setAttribute("errMessage", thesisCreated);
            request.getRequestDispatcher("/tHomepage.jsp").forward(request, response);
        }
    }
}