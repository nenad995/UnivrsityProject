package controller;

import bean.ReviewerBean;
import dao.ReviewerDao;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(name = "AddReviewerServlet")
public class AddReviewerServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //Get data from the form
        int reviewerID = Integer.parseInt(request.getParameter("reviewerID"));
        int thesisID = Integer.parseInt(request.getParameter("thesisID"));
        //Perform ADD query
        ReviewerBean reviewerBean = new ReviewerBean();
        reviewerBean.setThesisID(thesisID);
        reviewerBean.setReviewerID(reviewerID);
        ReviewerDao rd = new ReviewerDao();
        rd.addReviewer(reviewerBean);
        //Reload page
        String url = "/SupervisorSearchThesesServlet";
        RequestDispatcher dispatcher = request.getRequestDispatcher(url);
        dispatcher.forward(request, response);
    }
}
