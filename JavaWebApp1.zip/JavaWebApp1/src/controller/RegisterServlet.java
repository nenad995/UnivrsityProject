package controller;

import bean.UserBean;
import dao.RegisterDao;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(name = "RegisterServlet")
public class RegisterServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        //Get form data
        String firstName = request.getParameter("first");
        String middleName = request.getParameter("middle");
        String lastName = request.getParameter("last");
        String userName = request.getParameter("uname");
        String password = request.getParameter("pwd");
        //Assign values to UserBean object
        UserBean userBean = new UserBean();
        userBean.setFirstName(firstName);
        userBean.setMiddleName(middleName);
        userBean.setLastName(lastName);
        userBean.setUsername(userName);
        userBean.setPassword(password);
        //Creating RegisterDao object to perform check and register
        RegisterDao registerDao = new RegisterDao();
        //Check if username already exists
        if (registerDao.doExist(userBean)) {
            //If NOT then register and redirect to Login (index) page
            String userRegistered = registerDao.registerUser(userBean);
            if (userRegistered.equals("SUCCESS.")) {
                request.getRequestDispatcher("/index.jsp").forward(request, response);
            } else {
                //If username exists display Error Message and reload page
                request.setAttribute("errMessage", userRegistered);
                request.getRequestDispatcher("/Register.jsp").forward(request, response);
            }
        } else {
            request.getRequestDispatcher("/Register.jsp").forward(request, response);
        }
    }
}
