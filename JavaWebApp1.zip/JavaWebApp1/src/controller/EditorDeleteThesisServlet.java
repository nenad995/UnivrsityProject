package controller;

import dao.ThesisDao;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(name = "EditorDeleteThesisServlet")
public class EditorDeleteThesisServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //Get thesisID
        int thesisID = Integer.parseInt(request.getParameter("thesisID"));
        //Use a delete query to delete a user
        ThesisDao thesisDao = new ThesisDao();
        thesisDao.deleteThesis(thesisID);
        //Make a reload
        String url = "/editorShowAllTheses";
        RequestDispatcher dispatcher = request.getRequestDispatcher(url);
        dispatcher.forward(request, response);
    }
}
