package controller;

import dao.UpdateSupervisorDao;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(name = "UpdateSupervisorServlet")
public class UpdateSupervisorServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int thesisID = Integer.parseInt(request.getParameter("thesisID"));
        int supervisorID = Integer.parseInt(request.getParameter("supervisorID"));
        UpdateSupervisorDao usd = new UpdateSupervisorDao();
        usd.doUpdate(thesisID, supervisorID);
        //Reload page
        String url = "/SupervisorSearchThesesServlet";
        RequestDispatcher dispatcher = request.getRequestDispatcher(url);
        dispatcher.forward(request, response);
    }
}
