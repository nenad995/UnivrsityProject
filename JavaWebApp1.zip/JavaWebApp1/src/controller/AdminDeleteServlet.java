package controller;

import dao.UserDao;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(name = "AdminDeleteServlet")
public class AdminDeleteServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //Get userID
        int userID = Integer.parseInt(request.getParameter("ID"));
        //Use a delete query to delete a user
        UserDao userDao = new UserDao();
        userDao.doDelete(userID);
        //Make a reload
        String url = "/AdminShowUsersServlet";
        RequestDispatcher dispatcher = request.getRequestDispatcher(url);
        dispatcher.forward(request, response);
    }
}
