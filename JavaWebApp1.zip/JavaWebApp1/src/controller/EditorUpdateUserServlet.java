package controller;

import bean.UserBean;
import dao.EditorDao;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(name = "EditorUpdateUserServlet")
public class EditorUpdateUserServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //Get the form data
        int userID = Integer.parseInt(request.getParameter("uid"));
        String firstName = request.getParameter("fName");
        String middleName = request.getParameter("mName");
        String lastName = request.getParameter("lName");
        UserBean userBean = new UserBean();
        userBean.setID(userID);
        userBean.setFirstName(firstName);
        userBean.setMiddleName(middleName);
        userBean.setLastName(lastName);
        //Use EditorUpdateUserQuery object to update the record
        EditorDao editorDao = new EditorDao();
        editorDao.editorDoUpdate(userBean);
        //pass control to showUsersTable
        String url = "/editorShowUsersInfo";
        RequestDispatcher dispatcher = request.getRequestDispatcher(url);
        dispatcher.forward(request, response);
    }
}
