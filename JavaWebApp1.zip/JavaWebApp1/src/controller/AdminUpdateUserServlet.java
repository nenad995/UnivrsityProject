package controller;

import bean.UserBean;
import dao.UpdateQueryDao;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(name = "AdminUpdateUserServlet")
public class AdminUpdateUserServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //Get the form data
        int userID = Integer.parseInt(request.getParameter("uid"));
        String firstName = request.getParameter("fName");
        String middleName = request.getParameter("mName");
        String lastName = request.getParameter("lName");
        String username = request.getParameter("uname");
        String password = request.getParameter("pwd");
        String userRole = request.getParameter("urole");

        UserBean userBean = new UserBean();
        userBean.setID(userID);
        userBean.setFirstName(firstName);
        userBean.setMiddleName(middleName);
        userBean.setLastName(lastName);
        userBean.setUsername(username);
        userBean.setPassword(password);
        userBean.setUserRole(userRole);

        //Use updatequery object to update the record
        UpdateQueryDao uq = new UpdateQueryDao();
        uq.doUpdate(userBean);

        //pass control to showUsersTable
        String url = "/AdminShowUsersServlet";
        RequestDispatcher dispatcher = request.getRequestDispatcher(url);
        dispatcher.forward(request, response);
    }
}
