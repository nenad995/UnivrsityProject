package controller;

import dao.ShowUsersInfoDao;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(name = "ShowReviewerServlet")
public class ShowReviewerServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //Get thesis ID
        int thesisID = Integer.parseInt(request.getParameter("thesisID"));
        //Use thesisID to perform select query from ShowUsersInfoDao
        ShowUsersInfoDao suid = new ShowUsersInfoDao();
        suid.showReviewer(thesisID);
        String resultReviewerTable = suid.printUsersInfoTable();
        request.setAttribute("resultReviewerTable", resultReviewerTable);
        //Redirect to recenzentInfoPage
        String url = "/reviewerInfoPage.jsp";
        RequestDispatcher dispatcher = request.getRequestDispatcher(url);
        dispatcher.forward(request, response);
    }
}
