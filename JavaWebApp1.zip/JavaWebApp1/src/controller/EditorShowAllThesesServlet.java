package controller;

import dao.ThesisDao;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(name = "EditorShowAllThesesServlet")
public class EditorShowAllThesesServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        ThesisDao td = new ThesisDao();
        td.showAllThese();
        String resultTable = td.printEditorThesisTable();
        request.setAttribute("resultTable", resultTable);
        String url = "resultThesis.jsp";
        RequestDispatcher dispatcher = request.getRequestDispatcher(url);
        dispatcher.forward(request, response);
    }
}
