package controller;
import bean.UserBean;
import dao.TeacherDao;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
@WebServlet(name = "TeacherUpdateServlet")
public class TeacherUpdateServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        int userID = (int) session.getAttribute("id");
        String ns = request.getParameter("naucnaStepen");
        String ad = request.getParameter("administrativnaDlaznost");
        String ka = request.getParameter("katedra");
        String vo = request.getParameter("vansnaOrganizacija");
        UserBean userBean = new UserBean();
        userBean.setID(userID);
        TeacherDao updateTeacherDao = new TeacherDao();
        String updatedTeacherInfo = updateTeacherDao.updateTeacherInfo(userBean, ns, ad, ka, vo);
        if (updatedTeacherInfo.equals("SUCCESS.")){
            request.getRequestDispatcher("/sHomepage.jsp").forward(request,response);
        } else {
            request.setAttribute("errMessage", updatedTeacherInfo);
            request.getRequestDispatcher("/StudentOrTeacher.jsp").forward(request,response);
        }
    }
}
