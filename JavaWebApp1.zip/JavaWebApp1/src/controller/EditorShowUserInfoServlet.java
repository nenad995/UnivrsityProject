package controller;

import dao.ShowUsersInfoDao;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(name = "EditorShowUserInfoServlet")
public class EditorShowUserInfoServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        ShowUsersInfoDao suid = new ShowUsersInfoDao();
        suid.showUsersInfo();
        String editorUsersInfoTable = suid.printEditorUsersInfoTable();
        request.setAttribute("resultTable", editorUsersInfoTable);
        RequestDispatcher dispatcher = request.getRequestDispatcher("/editorUserInfo.jsp");
        dispatcher.forward(request, response);
    }
}
