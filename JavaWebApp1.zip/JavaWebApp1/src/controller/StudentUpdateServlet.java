package controller;

import bean.UserBean;
import dao.StudentDao;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@WebServlet(name = "StudentUpdateServlet")
public class StudentUpdateServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        int userID = (int) session.getAttribute("id");
        int facultyNumber = Integer.parseInt(request.getParameter("studentFacNum"));
        UserBean userBean = new UserBean();
        userBean.setID(userID);
        StudentDao studentDao = new StudentDao();
        String updatedStudentInfo = studentDao.updateStudentInfo(userBean, facultyNumber);
        if (updatedStudentInfo.equals("SUCCESS.")){
            request.getRequestDispatcher("/sHomepage.jsp").forward(request, response);
        } else {
            request.setAttribute("errMessage", updatedStudentInfo);
            request.getRequestDispatcher("/StudentOrTeacher.jsp").forward(request, response);
        }
    }
}
