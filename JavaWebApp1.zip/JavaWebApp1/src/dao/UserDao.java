package dao;

import bean.DBConnection;
import bean.UserBean;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class UserDao {
    Connection conn;
    PreparedStatement ps;
    ResultSet rs;

    //Get users from users table and their information
    public void showAllUsers (){
        String query = "SELECT * FROM users";

        conn = DBConnection.createConnection();
        try {
            ps = conn.prepareStatement(query);
            rs = ps.executeQuery();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    //Print results of showAllUsers methods as an HTML Table
    public String printUsersTable() {
        String table = "";
        try {
            table += "<table id=\"results\">";
            table += "<tr>";
            table += "<th>ID</th>";
            table += "<th>First Name</th>";
            table += "<th>Middle Name</th>";
            table += "<th>Last Name</th>";
            table += "<th>Username</th>";
            table += "<th>Password</th>";
            table += "<th>Users Role</th>";
            table += "</tr>";
            while (rs.next()) {
                UserBean userBean = new UserBean();
                userBean.setID(rs.getInt("ID"));
                userBean.setFirstName(rs.getString("FirstName"));
                userBean.setMiddleName(rs.getString("MiddleName"));
                userBean.setLastName(rs.getString("LastName"));
                userBean.setUsername(rs.getString("Username"));
                userBean.setPassword(rs.getString("Password"));
                userBean.setUserRole(rs.getString("UserRole"));

                table += "<tr>";
                table += "<td>";
                table += userBean.getID();
                table += "</td>";
                table += "<td>";
                table += userBean.getFirstName();
                table += "</td>";
                table += "<td>";
                table += userBean.getMiddleName();
                table += "</td>";
                table += "<td>";
                table += userBean.getLastName();
                table += "</td>";
                table += "<td>";
                table += userBean.getUsername();
                table += "</td>";
                table += "<td>";
                table += userBean.getPassword();
                table += "</td>";
                table += "<td>";
                table += userBean.getUserRole();
                table += "</td>";
                table += "<td>";
                table += "<a href=update?ID="+ userBean.getID() +">Update</a>";
                table += "</td>";
                table += "<td>";
                table += "<a href=delete?ID="+ userBean.getID() +">Delete</a>";
                table += "</td>";
                table += "</tr>";
            }
            table += "</table>";
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return table;
    }

    public void doDelete (int userID){
        conn = DBConnection.createConnection();
        String query = "DELETE FROM users WHERE ID=?";
        try {
            ps = conn.prepareStatement(query);
            ps.setInt(1, userID);
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
