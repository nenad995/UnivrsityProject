package dao;

import bean.DBConnection;
import bean.UserBean;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class RegisterDao {
    //Register User (Insert entered data to users table)
    public String registerUser (UserBean userBean){
        String fName = userBean.getFirstName();
        String mName = userBean.getMiddleName();
        String lName = userBean.getLastName();
        String uName = userBean.getUsername();
        String pwd = userBean.getPassword();
        Connection conn = null;
        PreparedStatement ps = null;
        String registerQuery = "INSERT INTO users (FirstName, MiddleName, LastName, Username, Password) VALUES (?,?,?,?,?)";
        conn = DBConnection.createConnection();
        try {
            ps = conn.prepareStatement(registerQuery);
            ps.setString(1, fName);
            ps.setString(2, mName);
            ps.setString(3, lName);
            ps.setString(4, uName);
            ps.setString(5, pwd);
            int i = ps.executeUpdate();
            if (i != 0){
                return "SUCCESS.";
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return "Something went wrong.";
    }
    //Check if User exists
    public boolean doExist(UserBean userBean){
        String username = userBean.getUsername();
        String checkQuery = "SELECT * FROM users WHERE Username='"+username+"'";
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        conn = DBConnection.createConnection();
        try {
            ps = conn.prepareStatement(checkQuery);
            rs = ps.executeQuery();

            if (rs.next()){
                return false;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return true;
    }
}
