package dao;
import bean.DBConnection;
import bean.UserBean;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
public class StudentDao {
    public String updateStudentInfo(UserBean userBean, int facNum){
        int ID = userBean.getID();
        String query = "INSERT INTO students (ID, FacultyNumber) VALUES (?, ?)";
        Connection conn = null;
        PreparedStatement ps = null;
        conn = DBConnection.createConnection();
        try {
            ps = conn.prepareStatement(query);
            ps.setInt(1, ID);
            ps.setInt(2, facNum);
            int i = ps.executeUpdate();
            if (i != 0){
                return "SUCCESS.";
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return "Something went wrong.";
    }
}
