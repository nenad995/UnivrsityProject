package dao;
import bean.DBConnection;
import bean.UserBean;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
public class TeacherDao {
    public String updateTeacherInfo(UserBean userBean, String ns, String ad, String ka, String vo){
        int ID = userBean.getID();
        String query = "INSERT INTO teachers (ID, NaucnaStepen, AdministrativnaDlaznost, Katedra, VansnaOrganizacija) VALUES (?, ?, ?, ?, ?)";
        Connection conn = null;
        PreparedStatement ps = null;
        conn = DBConnection.createConnection();
        try {
            ps = conn.prepareStatement(query);
            ps.setInt(1, ID);
            ps.setString(2, ns);
            ps.setString(3, ad);
            ps.setString(4, ka);
            ps.setString(5, vo);
            int i = ps.executeUpdate();
            if (i != 0){
                return "SUCCESS.";
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return "Something went wrong.";
    }
}