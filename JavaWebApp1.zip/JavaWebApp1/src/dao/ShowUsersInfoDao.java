package dao;

import bean.DBConnection;
import bean.UserBean;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ShowUsersInfoDao {
    Connection conn = DBConnection.createConnection();
    PreparedStatement ps;
    ResultSet rs;

    public void showTeachers (){
        String query = "SELECT ID, FirstName, MiddleName, LastName FROM users WHERE NOT Username='admin' AND NOT Username='editor'" +
                "AND ID IN (SELECT ID FROM teachers)";

        try {
            ps = conn.prepareStatement(query);
            rs = ps.executeQuery();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public String printUsersInfoTable() {
        String table = "";
        try {
            table += "<table id=\"results\">";
            table += "<tr>";
            table += "<th>ID</th>";
            table += "<th>First Name</th>";
            table += "<th>Middle Name</th>";
            table += "<th>Last Name</th>";
            table += "</tr>";
            while (rs.next()) {
                UserBean userBean = new UserBean();
                userBean.setID(rs.getInt("ID"));
                userBean.setFirstName(rs.getString("FirstName"));
                userBean.setMiddleName(rs.getString("MiddleName"));
                userBean.setLastName(rs.getString("LastName"));

                table += "<tr>";
                table += "<td>";
                table += userBean.getID();
                table += "</td>";
                table += "<td>";
                table += userBean.getFirstName();
                table += "</td>";
                table += "<td>";
                table += userBean.getMiddleName();
                table += "</td>";
                table += "<td>";
                table += userBean.getLastName();
                table += "</td>";
                table += "</tr>";
            }
            table += "</table>";
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return table;
    }

    public void showReviewer (int thesisID){
        String query = "SELECT ID, FirstName, MiddleName, LastName FROM users WHERE NOT Username='admin' AND NOT Username='editor'" +
                "AND ID IN (SELECT ID FROM recenzent WHERE thesisID=?)";

        try {
            ps = conn.prepareStatement(query);
            ps.setInt(1, thesisID);
            rs = ps.executeQuery();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void showUsersInfo (){
        String query = "SELECT ID, FirstName, MiddleName, LastName FROM users WHERE NOT Username='admin' AND NOT Username='editor'";
        try {
            ps = conn.prepareStatement(query);
            rs = ps.executeQuery();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public String printEditorUsersInfoTable() {
        String table = "";
        try {
            table += "<table id=\"results\">";
            table += "<tr>";
            table += "<th>ID</th>";
            table += "<th>First Name</th>";
            table += "<th>Middle Name</th>";
            table += "<th>Last Name</th>";
            table += "</tr>";
            while (rs.next()) {
                UserBean userBean = new UserBean();
                userBean.setID(rs.getInt("ID"));
                userBean.setFirstName(rs.getString("FirstName"));
                userBean.setMiddleName(rs.getString("MiddleName"));
                userBean.setLastName(rs.getString("LastName"));
                table += "<tr>";
                table += "<td>";
                table += userBean.getID();
                table += "</td>";
                table += "<td>";
                table += userBean.getFirstName();
                table += "</td>";
                table += "<td>";
                table += userBean.getMiddleName();
                table += "</td>";
                table += "<td>";
                table += userBean.getLastName();
                table += "</td>";
                table += "<td>";
                table += "<a href=updateuser?ID="+userBean.getID()+">Update User</a>";
                table += "</td>";
                table += "</tr>";
            }
            table += "</table>";
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return table;
    }
}
