package dao;
import bean.DBConnection;
import bean.UserBean;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
public class LoginDao {
    public String login(UserBean userBean){
        String username = userBean.getUsername();
        String password = userBean.getPassword();
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        String dbUsername = "";
        String dbPassword = "";
        conn = DBConnection.createConnection();
        String query = "SELECT Username, Password FROM users";
        try {
            ps = conn.prepareStatement(query);
            rs = ps.executeQuery();
            while (rs.next()){
                dbUsername = rs.getString("Username");
                dbPassword = rs.getString("Password");
                if ((username.equals(dbUsername)) && (password.equals(dbPassword))){
                    return "SUCCESS.";
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return "Invalid Username or Password.";
    }
    //Obtain logged user's ID
    public int obtainUserID(UserBean userBean){
        String username = userBean.getUsername();
        String query = "SELECT ID FROM users WHERE Username='"+username+"'";
        int loggedUserID = 0;
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        conn = DBConnection.createConnection();
        try {
            ps = conn.prepareStatement(query);
            rs = ps.executeQuery();
            while (rs.next()){
                loggedUserID = rs.getInt("ID");
                return loggedUserID;
            }
        }
        catch (SQLException e) {
            e.printStackTrace();
        } return 0;
    }
    //Check if ID of logged user exists in students table
    public boolean isStudent(int id){
        String checkQuery = "SELECT * FROM students WHERE ID='"+id+"'";
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        conn = DBConnection.createConnection();
        try {
            ps = conn.prepareStatement(checkQuery);
            rs = ps.executeQuery();
            while (rs.next())
                return true;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
    //Check if ID of logged user exists in teachers table
    public boolean isTeacher(int id){
        String checkQuery = "SELECT * FROM teachers WHERE ID='"+id+"'";
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        conn = DBConnection.createConnection();
        try {
            ps = conn.prepareStatement(checkQuery);
            rs = ps.executeQuery();
            while (rs.next())
                return true;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
}
