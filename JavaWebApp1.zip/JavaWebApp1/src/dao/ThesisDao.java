package dao;

import bean.DBConnection;
import bean.ThesisBean;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;

public class ThesisDao {
    Connection conn = null;
    PreparedStatement ps = null;
    ResultSet rs = null;
    //Obtain students Faculty Number
    public int getFacultyNumber (int ID){
        int facNum = 0;
        String query = "SELECT FacultyNumber FROM students WHERE ID="+ID;
        conn = DBConnection.createConnection();
        try {
            ps = conn.prepareStatement(query);
            rs = ps.executeQuery();
            while (rs.next()){
                facNum = rs.getInt("FacultyNumber");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return facNum;
    }
    //Get thesis row for given Faculty Number
    public void showYourThesis(int facNum){
        String query = "SELECT * FROM thesis WHERE FacultyNumber='"+facNum+"'";
        conn = DBConnection.createConnection();
        try {
            ps = conn.prepareStatement(query);
            rs = ps.executeQuery();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    //Print results of above methods as an HTML Table
    public String printThesisTable() {
        String table = "";
        try {
            table += "<table id=\"results\">";
            table += "<tr>";
            table += "<th>Thesis ID</th>";
            table += "<th>Faculty Number</th>";
            table += "<th>Supervisor ID</th>";
            table += "<th>Defense Date</th>";
            table += "<th>Theme</th>";
            table += "<th>Short Description</th>";
            table += "<th>Chapters</th>";
            table += "</tr>";
            if (rs.next() == false){
                table += "<tr align=\"center\">";
                table += "<td colspan=\"7\">";
                table += "No Records";
                table += "</td>";
                table += "</tr>";
                table += "</table>";
            } else {
                do {
                    ThesisBean thesisBean = new ThesisBean();
                    thesisBean.setThesisID(rs.getInt("thesisID"));
                    thesisBean.setFacNum(rs.getInt("FacultyNumber"));
                    thesisBean.setTeacherID(rs.getInt("ID"));
                    thesisBean.setDate(rs.getDate("DefenseDate"));
                    thesisBean.setTheme(rs.getString("Theme"));
                    thesisBean.setDescription(rs.getString("ShortDescription"));
                    thesisBean.setContent(rs.getString("Content"));
                    table += "<tr>";
                    table += "<td>";
                    table += thesisBean.getThesisID();
                    table += "</td>";
                    table += "<td>";
                    table += "0"+thesisBean.getFacNum();
                    table += "</td>";
                    table += "<td>";
                    table += thesisBean.getTeacherID();
                    table += "</td>";
                    table += "<td>";
                    table += thesisBean.getDate();
                    table += "</td>";
                    table += "<td>";
                    table += thesisBean.getTheme();
                    table += "</td>";
                    table += "<td>";
                    table += thesisBean.getDescription();
                    table += "</td>";
                    table += "<td>";
                    table += thesisBean.getContent();
                    table += "</td>";
                    table += "<td>";
                    table += "<a href=showReviewer?thesisID="+thesisBean.getThesisID()+">Show Reviewer</a>";
                    table += "</td>";
                    table += "</tr>";
                }
                while (rs.next());
                table += "</table>";
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return table;
    }
    //Get thesis records for given title or part of title
    public void searchForThesisByTitle(String title) {
        String query = "SELECT * FROM thesis WHERE Theme LIKE '%" + title + "%'";
        conn = DBConnection.createConnection();
        try {
            ps = conn.prepareStatement(query);
            rs = ps.executeQuery();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    //Get thesis records for given thesisID
    public void searchForThesisByID(int thesisID) {
        String query = "SELECT * FROM thesis WHERE thesisID='" + thesisID + "'";
        conn = DBConnection.createConnection();
        try {
            ps = conn.prepareStatement(query);
            rs = ps.executeQuery();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    //HTML table for searchByTitle and byThesisID
    public String printResultTable() {
        String table = "";
        try {
            table += "<table id=\"results\">";
            table += "<tr>";
            table += "<th>Thesis ID</th>";
            table += "<th>Faculty Number</th>";
            table += "<th>Supervisor ID</th>";
            table += "<th>Defense Date</th>";
            table += "<th>Theme</th>";
            table += "<th>Short Description</th>";
            table += "<th>Chapters</th>";
            table += "</tr>";
            if (rs.next() == false){
                table += "<tr align=\"center\">";
                table += "<td colspan=\"7\">";
                table += "No Records";
                table += "</td>";
                table += "</tr>";
                table += "</table>";
            } else {
                do {
                    ThesisBean thesisBean = new ThesisBean();
                    thesisBean.setThesisID(rs.getInt("thesisID"));
                    thesisBean.setFacNum(rs.getInt("FacultyNumber"));
                    thesisBean.setTeacherID(rs.getInt("ID"));
                    thesisBean.setDate(rs.getDate("DefenseDate"));
                    thesisBean.setTheme(rs.getString("Theme"));
                    thesisBean.setDescription(rs.getString("ShortDescription"));
                    thesisBean.setContent(rs.getString("Content"));
                    table += "<tr>";
                    table += "<td>";
                    table += thesisBean.getThesisID();
                    table += "</td>";
                    table += "<td>";
                    table += "0"+thesisBean.getFacNum();
                    table += "</td>";
                    table += "<td>";
                    table += thesisBean.getTeacherID();
                    table += "</td>";
                    table += "<td>";
                    table += thesisBean.getDate();
                    table += "</td>";
                    table += "<td>";
                    table += thesisBean.getTheme();
                    table += "</td>";
                    table += "<td>";
                    table += thesisBean.getDescription();
                    table += "</td>";
                    table += "<td>";
                    table += thesisBean.getContent();
                    table += "</td>";
                    table += "</tr>";
                }
                while (rs.next());
                table += "</table>";
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return table;
    }
    //Get thesis ID for given Faculty Number
    public int showYourThesisID(int facNum){
        String query = "SELECT thesisID FROM thesis WHERE FacultyNumber='"+facNum+"'";
        int facultyNumber = 0;
        conn = DBConnection.createConnection();
        try {
            ps = conn.prepareStatement(query);
            rs = ps.executeQuery();
            while (rs.next()){
                facultyNumber = rs.getInt("thesisID");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return facultyNumber;
    }

    //Create new thesis record with logged teacher as a supervisor
    public String createThesis (ThesisBean thesisBean) throws ParseException {
        int facNum = thesisBean.getFacNum();
        int id = thesisBean.getTeacherID();
        String defDate = thesisBean.getDefenseDate();
        java.sql.Date defenseDate = thesisBean.processDate(defDate);
        String theme = thesisBean.getTheme();
        String shortDescription = thesisBean.getDescription();
        String content = thesisBean.getContent();
        String query = "INSERT INTO thesis (FacultyNumber, ID, DefenseDate, Theme, ShortDescription, Content) VALUES (?,?,?,?,?,?)";
        conn = DBConnection.createConnection();
        try {
            ps = conn.prepareStatement(query);
            ps.setInt(1, facNum);
            ps.setInt(2, id);
            ps.setDate(3, defenseDate);
            ps.setString(4, theme);
            ps.setString(5, shortDescription);
            ps.setString(6, content);
            int i = ps.executeUpdate();

            if (i != 0){
                return "SUCCESS.";
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return "Something went wrong.";
    }
    //Get thesis records for logged teacher
    public void showSupervisorTheses(int userID){
        String query = "SELECT * FROM thesis WHERE ID='"+userID+"'";
        conn = DBConnection.createConnection();
        try {
            ps = conn.prepareStatement(query);
            rs = ps.executeQuery();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public String printTeacherThesisTable() {
        String table = "";
        try {
            table += "<table id=\"results\">";
            table += "<tr>";
            table += "<th>Thesis ID</th>";
            table += "<th>Faculty Number</th>";
            table += "<th>Superviros ID</th>";
            table += "<th>Defense Date</th>";
            table += "<th>Theme</th>";
            table += "<th>Short Description</th>";
            table += "<th>Chapters</th>";
            table += "</tr>";
            if (rs.next() == false){
                table += "<tr align=\"center\">";
                table += "<td colspan=\"7\">";
                table += "No Records";
                table += "</td>";
                table += "</tr>";
                table += "</table>";
            } else {
                do {
                    ThesisBean thesisBean = new ThesisBean();
                    thesisBean.setThesisID(rs.getInt("thesisID"));
                    thesisBean.setFacNum(rs.getInt("FacultyNumber"));
                    thesisBean.setTeacherID(rs.getInt("ID"));
                    thesisBean.setDate(rs.getDate("DefenseDate"));
                    thesisBean.setTheme(rs.getString("Theme"));
                    thesisBean.setDescription(rs.getString("ShortDescription"));
                    thesisBean.setContent(rs.getString("Content"));
                    table += "<tr>";
                    table += "<td>";
                    table += thesisBean.getThesisID();
                    table += "</td>";
                    table += "<td>";
                    table += "0"+thesisBean.getFacNum();
                    table += "</td>";
                    table += "<td>";
                    table += thesisBean.getTeacherID();
                    table += "</td>";
                    table += "<td>";
                    table += thesisBean.getDate();
                    table += "</td>";
                    table += "<td>";
                    table += thesisBean.getTheme();
                    table += "</td>";
                    table += "<td>";
                    table += thesisBean.getDescription();
                    table += "</td>";
                    table += "<td>";
                    table += thesisBean.getContent();
                    table += "</td>";
                    table += "<td>";
                    table += "<a href=updateSupervisor?thesisID="+ thesisBean.getThesisID() +
                            "&supervisorID="+thesisBean.getTeacherID()+">Update Supervisor Table</a>";
                    table += "</td>";
                    table += "<td>";
                    table += "<a href=addReviewer?thesisID="+ thesisBean.getThesisID() +">Add Reviewer</a>";
                    table += "</td>";
                    table += "<td>";
                    table += "<a href=remove?thesisID="+ thesisBean.getThesisID() +">Remove</a>";
                    table += "</td>";
                    table += "</tr>";
                }
                while (rs.next());
                table += "</table>";
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return table;
    }

    public void deleteThesis (int thesisID){
        conn = DBConnection.createConnection();
        String query = "DELETE FROM thesis WHERE thesisID=?";
        try {
            ps = conn.prepareStatement(query);
            ps.setInt(1, thesisID);
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public void showAllThese(){
        String query = "SELECT * FROM thesis";

        conn = DBConnection.createConnection();
        try {
            ps = conn.prepareStatement(query);
            rs = ps.executeQuery();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public String printEditorThesisTable() {
        String table = "";
        try {
            table += "<table id=\"results\">";
            table += "<tr>";
            table += "<th>Thesis ID</th>";
            table += "<th>Faculty Number</th>";
            table += "<th>Supervisor ID</th>";
            table += "<th>Defense Date</th>";
            table += "<th>Theme</th>";
            table += "<th>Short Description</th>";
            table += "<th>Chapters</th>";
            table += "</tr>";
            if (rs.next() == false){
                table += "<tr align=\"center\">";
                table += "<td colspan=\"7\">";
                table += "No Records";
                table += "</td>";
                table += "</tr>";
                table += "</table>";
            } else {
                do {
                    ThesisBean thesisBean = new ThesisBean();
                    thesisBean.setThesisID(rs.getInt("thesisID"));
                    thesisBean.setFacNum(rs.getInt("FacultyNumber"));
                    thesisBean.setTeacherID(rs.getInt("ID"));
                    thesisBean.setDate(rs.getDate("DefenseDate"));
                    thesisBean.setTheme(rs.getString("Theme"));
                    thesisBean.setDescription(rs.getString("ShortDescription"));
                    thesisBean.setContent(rs.getString("Content"));
                    table += "<tr>";
                    table += "<td>";
                    table += thesisBean.getThesisID();
                    table += "</td>";
                    table += "<td>";
                    table += "0"+thesisBean.getFacNum();
                    table += "</td>";
                    table += "<td>";
                    table += thesisBean.getTeacherID();
                    table += "</td>";
                    table += "<td>";
                    table += thesisBean.getDate();
                    table += "</td>";
                    table += "<td>";
                    table += thesisBean.getTheme();
                    table += "</td>";
                    table += "<td>";
                    table += thesisBean.getDescription();
                    table += "</td>";
                    table += "<td>";
                    table += thesisBean.getContent();
                    table += "</td>";
                    table += "<td>";
                    table += "<a href=updatefn?FacultyNumber="+ thesisBean.getFacNum() +">Update Student</a>";
                    table += "</td>";
                    table += "<td>";
                    table += "<a href=deleteThesis?thesisID="+ thesisBean.getThesisID() +">Delete</a>";
                    table += "</td>";
                    table += "</tr>";
                }
                while (rs.next());
                table += "</table>";
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return table;
    }
}
