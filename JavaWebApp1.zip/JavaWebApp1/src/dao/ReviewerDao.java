package dao;

import bean.DBConnection;
import bean.ReviewerBean;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class ReviewerDao {
    Connection conn = DBConnection.createConnection();
    public void addReviewer (ReviewerBean reviewerBean){
        String query = "INSERT INTO recenzent (thesisID, ID) VALUES (?, ?)";
        try {
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setInt(1, reviewerBean.getThesisID());
            ps.setInt(2, reviewerBean.getReviewerID());
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
