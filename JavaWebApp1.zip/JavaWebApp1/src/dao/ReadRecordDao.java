package dao;

import bean.DBConnection;
import bean.UserBean;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ReadRecordDao {
    public UserBean doRea(int userID){
        //Connect to DB
        Connection conn = DBConnection.createConnection();
        ResultSet rs = null;
        //Create User object
        UserBean userBean = new UserBean();
        //Get user from DB
        String query = "SELECT * FROM users WHERE ID=?";
        try {
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setInt(1, userID);

            rs = ps.executeQuery();

            while(rs.next()) {
                userBean.setID(rs.getInt("ID"));
                userBean.setFirstName(rs.getString("FirstName"));
                userBean.setMiddleName(rs.getString("MiddleName"));
                userBean.setLastName(rs.getString("LastName"));
                userBean.setUsername(rs.getString("Username"));
                userBean.setPassword(rs.getString("Password"));
                userBean.setUserRole(rs.getString("UserRole"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return userBean;
    }
}
