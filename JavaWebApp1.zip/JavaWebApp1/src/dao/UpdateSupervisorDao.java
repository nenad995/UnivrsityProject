package dao;

import bean.DBConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class UpdateSupervisorDao {
    Connection conn = DBConnection.createConnection();
    public void doUpdate (int thesisID, int rukovoditelID){
        String query = "INSERT INTO rukovoditel (thesisID, ID) VALUES (?,?)";
        try {
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setInt(1, thesisID);
            ps.setInt(2, rukovoditelID);
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
