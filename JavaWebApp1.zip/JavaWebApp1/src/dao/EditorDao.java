package dao;

import bean.DBConnection;
import bean.StudentBean;
import bean.UserBean;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class EditorDao {
    public UserBean editorDoRead(int userID){
        //Connect to DB
        Connection conn = DBConnection.createConnection();
        ResultSet rs = null;
        //Create User object
        UserBean userBean = new UserBean();
        //Get user from DB
        String query = "SELECT ID, FirstName, MiddleName, LastName FROM users WHERE ID=?";
        try {
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setInt(1, userID);
            rs = ps.executeQuery();
            while(rs.next()) {
                userBean.setID(rs.getInt("ID"));
                userBean.setFirstName(rs.getString("FirstName"));
                userBean.setMiddleName(rs.getString("MiddleName"));
                userBean.setLastName(rs.getString("LastName"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return userBean;
    }

    public void editorDoUpdate(UserBean userBean){
        Connection conn = DBConnection.createConnection();
        String query = "UPDATE users SET FirstName=?, MiddleName=?, LastName=? WHERE ID=?";
        try {
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setString(1, userBean.getFirstName());
            ps.setString(2, userBean.getMiddleName());
            ps.setString(3, userBean.getLastName());
            ps.setInt(4, userBean.getID());
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public StudentBean editorDoReadStudent(int facNum){
        //Connect to DB
        Connection conn = DBConnection.createConnection();
        ResultSet rs = null;
        //Create Student object
        StudentBean studentBean = new StudentBean();
        //Get user from DB
        String query = "SELECT * FROM students WHERE FacultyNumber=?";
        try {
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setInt(1, facNum);
            rs = ps.executeQuery();
            while(rs.next()) {
                studentBean.setId(rs.getInt("ID"));
                studentBean.setFacultyNumber(rs.getInt("FacultyNumber"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return studentBean;
    }

    public void editorDoUpdateStudent(StudentBean studentBean){
        Connection conn = DBConnection.createConnection();
        String query = "UPDATE students SET FacultyNumber=? WHERE ID=?";
        try {
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setInt(1, studentBean.getFacultyNumber());
            ps.setInt(2, studentBean.getId());
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

}
