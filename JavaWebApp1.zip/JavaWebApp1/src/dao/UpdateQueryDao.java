package dao;

import bean.DBConnection;
import bean.UserBean;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class UpdateQueryDao {
    Connection conn = DBConnection.createConnection();

    public void doUpdate(UserBean userBean){
        String query = "UPDATE users SET FirstName=?, MiddleName=?, LastName=?, Username=?, Password=?, UserRole=? WHERE ID=?";

        try {
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setString(1, userBean.getFirstName());
            ps.setString(2, userBean.getMiddleName());
            ps.setString(3, userBean.getLastName());
            ps.setString(4, userBean.getUsername());
            ps.setString(5, userBean.getPassword());
            ps.setString(6, userBean.getUserRole());
            ps.setInt(7, userBean.getID());

            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
