package bean;

public class ReviewerBean {
    private int reviewerID;
    private int thesisID;
    public int getReviewerID() {
        return reviewerID;
    }
    public void setReviewerID(int reviewerID) {
        this.reviewerID = reviewerID;
    }
    public int getThesisID() {
        return thesisID;
    }
    public void setThesisID(int thesisID) {
        this.thesisID = thesisID;
    }
}
