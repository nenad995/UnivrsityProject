package bean;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
public class DBConnection {
    public static Connection createConnection(){
        Connection conn = null;
        String dbName = "vutpdb";   //Set your DB name
        String url = "jdbc:mysql://localhost:3306/"+dbName; //Set URL and PORT to your DB
        String user = "root";   //Set username for your DB
        String pass = "ennoiretblanc";  //Set password for your DB
        try {
            Class.forName("com.mysql.cj.jdbc.Driver"); //Loading MySQL drivers
            conn = DriverManager.getConnection(url,user,pass);  //Attempting to connect
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
        return conn;
    }
}

