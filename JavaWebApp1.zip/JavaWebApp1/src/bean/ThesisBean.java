package bean;
import java.util.Date;
public class ThesisBean {
    private int thesisID;
    private int facNum;
    private int teacherID;
    private String defenseDate;
    private Date date;
    private String theme;
    private String description;
    private String content;
    public int getThesisID() {
        return thesisID;
    }
    public void setThesisID(int thesisID) {
        this.thesisID = thesisID;
    }
    public int getFacNum() {
        return facNum;
    }
    public void setFacNum(int facNum) {
        this.facNum = facNum;
    }
    public int getTeacherID() {
        return teacherID;
    }
    public void setTeacherID(int teacherID) {
        this.teacherID = teacherID;
    }
    public String getDefenseDate() {
        return defenseDate;
    }
    public void setDefenseDate(String defenseDate) {
        this.defenseDate = defenseDate;
    }
    public Date getDate() {
        return date;
    }
    public void setDate(Date date) {
        this.date = date;
    }
    public String getTheme() {
        return theme;
    }
    public void setTheme(String theme) {
        this.theme = theme;
    }
    public String getDescription() {
        return description;
    }
    public void setDescription(String description) {
        this.description = description;
    }
    public String getContent() {
        return content;
    }
    public void setContent(String content) {
        this.content = content;
    }
    public java.sql.Date processDate (String defdate) {
        java.sql.Date defenseDate = java.sql.Date.valueOf(defdate);
        return defenseDate;
    }
}
