package bean;

public class StudentBean {
    private int id;
    private int facultyNumber;
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public int getFacultyNumber() {
        return facultyNumber;
    }
    public void setFacultyNumber(int facultyNumber) {
        this.facultyNumber = facultyNumber;
    }
}
